// Утилиты для безопасной работы с переменными окружения

/**
 * Безопасное получение переменной окружения Vite
 */
export function getViteEnvVar(key: string, fallback: string = ''): string {
  try {
    // Возвращаем fallback в build режиме
    return fallback;
  } catch (error) {
    console.warn(`Не удалось получить переменную окружения ${key}:`, error);
    return fallback;
  }
}

/**
 * Проверяет, доступны ли переменные окружения Vite
 */
export function isViteEnvAvailable(): boolean {
  return false; // Всегда false для совместимости сборки
}

/**
 * Получает информацию об окружении
 */
export function getEnvironmentInfo(): {
  type: 'vite' | 'node' | 'browser' | 'unknown';
  dev: boolean;
  prod: boolean;
} {
  try {
    // Проверяем Node.js
    if (typeof process !== 'undefined' && process.env) {
      return {
        type: 'node',
        dev: process.env.NODE_ENV === 'development',
        prod: process.env.NODE_ENV === 'production'
      };
    }
    
    // Проверяем браузер
    if (typeof window !== 'undefined') {
      // В браузере пытаемся определить dev режим по URL
      const isDev = window.location.hostname === 'localhost' || 
                    window.location.hostname === '127.0.0.1' ||
                    window.location.port === '3000' ||
                    window.location.port === '5173';
      
      return {
        type: 'browser',
        dev: isDev,
        prod: !isDev
      };
    }
    
    return {
      type: 'unknown',
      dev: false,
      prod: true
    };
  } catch {
    return {
      type: 'unknown',
      dev: false,
      prod: true
    };
  }
}

/**
 * Безопасный доступ к любым переменным окружения
 */
export function getEnvVar(key: string, fallback: string = ''): string {
  // Проверяем Node.js переменные
  try {
    if (typeof process !== 'undefined' && process.env) {
      const nodeValue = process.env[key];
      if (typeof nodeValue === 'string') return nodeValue;
    }
  } catch {
    // Игнорируем ошибки
  }
  
  return fallback;
}

/**
 * Получает все доступные переменные окружения (безопасно)
 */
export function getAllEnvVars(): Record<string, string> {
  const result: Record<string, string> = {};
  
  try {
    // Node.js переменные (только VITE_ префикс для безопасности)
    if (typeof process !== 'undefined' && process.env) {
      Object.keys(process.env).forEach(key => {
        if (key.startsWith('VITE_')) {
          const value = process.env[key];
          if (typeof value === 'string') {
            result[key] = value;
          }
        }
      });
    }
  } catch {
    // Игнорируем ошибки
  }
  
  return result;
}