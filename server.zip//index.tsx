import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-4765f130/health", (c) => {
  return c.json({ status: "ok" });
});

// Сохранение результатов тестов
app.post("/make-server-4765f130/save-test-results", async (c) => {
  try {
    const { patientId, testType, results, recommendations, timestamp } = await c.req.json();
    
    const testData = {
      patientId,
      testType,
      results,
      recommendations,
      timestamp: timestamp || new Date().toISOString(),
      id: crypto.randomUUID()
    };
    
    await kv.set(`test:${testData.id}`, testData);
    await kv.set(`patient:${patientId}:latest`, testData.id);
    
    console.log(`Test results saved for patient ${patientId}, test type: ${testType}`);
    return c.json({ success: true, testId: testData.id });
  } catch (error) {
    console.log(`Error saving test results: ${error}`);
    return c.json({ error: "Failed to save test results" }, 500);
  }
});

// Получение результатов тестов пациента
app.get("/make-server-4765f130/patient/:patientId/tests", async (c) => {
  try {
    const patientId = c.req.param("patientId");
    const tests = await kv.getByPrefix(`test:`);
    
    const patientTests = tests.filter(test => test.patientId === patientId);
    
    return c.json({ tests: patientTests });
  } catch (error) {
    console.log(`Error fetching patient tests: ${error}`);
    return c.json({ error: "Failed to fetch patient tests" }, 500);
  }
});

// Генерация ИИ рекомендаций (заглушка для демо)
app.post("/make-server-4765f130/generate-ai-recommendations", async (c) => {
  try {
    const { testResults, testType } = await c.req.json();
    
    // Здесь будет интеграция с ИИ API (OpenAI, Claude и т.д.)
    // Пока что возвращаем базовые рекомендации
    let recommendations = [];
    
    if (testType === "PHQ-9") {
      const score = testResults.totalScore || 0;
      if (score >= 20) {
        recommendations = [
          "Требуется немедленная консультация психиатра",
          "Рассмотреть возможность стационарного лечения",
          "Оценка суицидального риска"
        ];
      } else if (score >= 15) {
        recommendations = [
          "Рекомендована психотерапия",
          "Рассмотреть медикаментозное лечение",
          "Регулярное наблюдение"
        ];
      } else if (score >= 10) {
        recommendations = [
          "Психотерапия может быть полезной",
          "Мониторинг состояния",
          "Работа с копинг-стратегиями"
        ];
      } else {
        recommendations = [
          "Поддержание текущего состояния",
          "Профилактические меры",
          "Регулярная самооценка"
        ];
      }
    }
    
    return c.json({ recommendations });
  } catch (error) {
    console.log(`Error generating AI recommendations: ${error}`);
    return c.json({ error: "Failed to generate recommendations" }, 500);
  }
});

// Отправка результатов врачу
app.post("/make-server-4765f130/send-to-doctor", async (c) => {
  try {
    const { doctorContact, patientName, testResults, contactMethod } = await c.req.json();
    
    console.log(`Sending results to doctor via ${contactMethod}: ${doctorContact}`);
    console.log(`Patient: ${patientName}`);
    console.log(`Test results:`, testResults);
    
    let notificationStatus = 'pending';
    let message = '';
    
    if (contactMethod === 'telegram') {
      try {
        const botToken = Deno.env.get('TELEGRAM_BOT_TOKEN');
        if (!botToken) {
          throw new Error('Telegram bot token not configured');
        }

        // Форматируем сообщение с результатами
        const formattedMessage = `
🏥 *Новые результаты тестирования*

👤 *Пациент:* ${patientName}
📋 *Тест:* ${testResults.testType || 'Не указан'}
📊 *Результат:* ${testResults.totalScore || 'N/A'} баллов
📅 *Дата:* ${new Date(testResults.timestamp || Date.now()).toLocaleDateString('ru-RU')}

📝 *ИИ-анализ:*
${testResults.aiAnalysis || 'Анализ не проведен'}

💡 *Рекомендации:*
${testResults.recommendations?.map((rec: string, i: number) => `${i + 1}. ${rec}`).join('\n') || 'Рекомендации не предоставлены'}
        `.trim();

        // Отправляем сообщение через Telegram Bot API
        const telegramResponse = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            chat_id: doctorContact.startsWith('@') ? doctorContact : doctorContact,
            text: formattedMessage,
            parse_mode: 'Markdown'
          })
        });

        const telegramResult = await telegramResponse.json();
        
        if (telegramResult.ok) {
          notificationStatus = 'sent';
          message = 'Результаты успешно отправлены врачу через Telegram';
        } else {
          throw new Error(`Telegram API error: ${telegramResult.description || 'Unknown error'}`);
        }
      } catch (telegramError) {
        console.log(`Telegram sending error: ${telegramError}`);
        notificationStatus = 'failed';
        message = `Ошибка отправки через Telegram: ${telegramError.message}`;
      }
    } else if (contactMethod === 'email') {
      // Здесь будет интеграция с Email API (например, Resend, SendGrid)
      // Пока что помечаем как отправленное
      notificationStatus = 'sent';
      message = 'Результаты отправлены врачу на email (функция в разработке)';
    }
    
    // Сохраняем отправку в историю
    const notificationData = {
      id: crypto.randomUUID(),
      doctorContact,
      patientName,
      testResults,
      contactMethod,
      timestamp: new Date().toISOString(),
      status: notificationStatus
    };
    
    await kv.set(`notification:${notificationData.id}`, notificationData);
    
    return c.json({ 
      success: notificationStatus === 'sent', 
      message,
      notificationId: notificationData.id 
    });
  } catch (error) {
    console.log(`Error sending to doctor: ${error}`);
    return c.json({ error: "Failed to send to doctor" }, 500);
  }
});

// Получение истории уведомлений
app.get("/make-server-4765f130/notifications", async (c) => {
  try {
    const notifications = await kv.getByPrefix("notification:");
    return c.json({ notifications });
  } catch (error) {
    console.log(`Error fetching notifications: ${error}`);
    return c.json({ error: "Failed to fetch notifications" }, 500);
  }
});

// Регистрация врачей
app.post("/make-server-4765f130/doctors/register", async (c) => {
  try {
    const { email, name, specialty, clinic, password } = await c.req.json();
    
    const doctorData = {
      id: crypto.randomUUID(),
      email,
      name,
      specialty,
      clinic,
      password, // В реальном приложении нужно хешировать
      registrationDate: new Date().toISOString(),
      isVerified: false
    };
    
    await kv.set(`doctor:${doctorData.id}`, doctorData);
    await kv.set(`doctor:email:${email}`, doctorData.id);
    
    return c.json({ success: true, doctorId: doctorData.id });
  } catch (error) {
    console.log(`Error registering doctor: ${error}`);
    return c.json({ error: "Failed to register doctor" }, 500);
  }
});

// Аутентификация врачей
app.post("/make-server-4765f130/doctors/login", async (c) => {
  try {
    const { email, password } = await c.req.json();
    
    const doctorIdData = await kv.get(`doctor:email:${email}`);
    if (!doctorIdData) {
      return c.json({ error: "Doctor not found" }, 404);
    }
    
    const doctorData = await kv.get(`doctor:${doctorIdData}`);
    if (!doctorData || doctorData.password !== password) {
      return c.json({ error: "Invalid credentials" }, 401);
    }
    
    return c.json({ 
      success: true, 
      doctor: {
        id: doctorData.id,
        email: doctorData.email,
        name: doctorData.name,
        specialty: doctorData.specialty,
        clinic: doctorData.clinic
      }
    });
  } catch (error) {
    console.log(`Error logging in doctor: ${error}`);
    return c.json({ error: "Failed to login" }, 500);
  }
});

Deno.serve(app.fetch);