import { projectId, publicAnonKey } from '../utils/supabase/info';

const BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-4765f130`;

interface TestResults {
  patientId: string;
  testType: string;
  results: any;
  recommendations?: string[];
  timestamp?: string;
}

interface DoctorRegistration {
  email: string;
  name: string;
  specialty: string;
  clinic: string;
  password: string;
}

interface DoctorLogin {
  email: string;
  password: string;
}

interface SendToDoctorRequest {
  doctorContact: string;
  patientName: string;
  testResults: any;
  contactMethod: 'telegram' | 'email';
}

class ApiService {
  private async makeRequest(endpoint: string, options: RequestInit = {}) {
    const url = `${BASE_URL}${endpoint}`;
    
    const defaultHeaders = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${publicAnonKey}`,
    };

    const response = await fetch(url, {
      ...options,
      headers: {
        ...defaultHeaders,
        ...options.headers,
      },
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`API Error: ${response.status} - ${error}`);
    }

    return response.json();
  }

  // Сохранение результатов тестов
  async saveTestResults(testResults: TestResults) {
    return this.makeRequest('/save-test-results', {
      method: 'POST',
      body: JSON.stringify(testResults),
    });
  }

  // Получение тестов пациента
  async getPatientTests(patientId: string) {
    return this.makeRequest(`/patient/${patientId}/tests`);
  }

  // Генерация ИИ рекомендаций
  async generateAIRecommendations(testResults: any, testType: string) {
    return this.makeRequest('/generate-ai-recommendations', {
      method: 'POST',
      body: JSON.stringify({ testResults, testType }),
    });
  }

  // Отправка результатов врачу
  async sendToDoctor(request: SendToDoctorRequest) {
    return this.makeRequest('/send-to-doctor', {
      method: 'POST',
      body: JSON.stringify(request),
    });
  }

  // Регистрация врача
  async registerDoctor(doctorData: DoctorRegistration) {
    return this.makeRequest('/doctors/register', {
      method: 'POST',
      body: JSON.stringify(doctorData),
    });
  }

  // Аутентификация врача
  async loginDoctor(credentials: DoctorLogin) {
    return this.makeRequest('/doctors/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    });
  }

  // Получение истории уведомлений
  async getNotifications() {
    return this.makeRequest('/notifications');
  }

  // Проверка здоровья сервера
  async healthCheck() {
    return this.makeRequest('/health');
  }
}

export const apiService = new ApiService();