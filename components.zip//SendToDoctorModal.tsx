import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { MessageCircle, Send, Phone, Mail, Check, AlertCircle } from 'lucide-react';
import { apiService } from '../services/apiService';

interface TestResult {
  testType: string;
  score: number;
  severity: string;
  recommendations: string[];
  date: string;
}

interface SendToDoctorModalProps {
  isOpen: boolean;
  onClose: () => void;
  patientName: string;
  testResults: TestResult[];
}

export function SendToDoctorModal({ isOpen, onClose, patientName, testResults }: SendToDoctorModalProps) {
  const [doctorContact, setDoctorContact] = useState('');
  const [contactMethod, setContactMethod] = useState<'telegram' | 'email'>('telegram');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  const handleSend = async () => {
    if (!doctorContact.trim()) {
      setError('Укажите контакт врача');
      return;
    }

    setLoading(true);
    setError('');

    try {
      await apiService.sendToDoctor({
        doctorContact,
        patientName,
        testResults: {
          tests: testResults,
          summary: generateSummary(),
          message: message || 'Результаты психологического тестирования пациента'
        },
        contactMethod
      });

      setSent(true);
      setTimeout(() => {
        setSent(false);
        onClose();
        resetForm();
      }, 2000);
    } catch (err) {
      setError('Ошибка при отправке результатов. Попробуйте еще раз.');
      console.error('Error sending to doctor:', err);
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setDoctorContact('');
    setContactMethod('whatsapp');
    setMessage('');
    setError('');
  };

  const generateSummary = () => {
    const highRiskTests = testResults.filter(test => test.severity === 'severe' || test.severity === 'high');
    const moderateRiskTests = testResults.filter(test => test.severity === 'moderate');
    
    return {
      totalTests: testResults.length,
      highRiskCount: highRiskTests.length,
      moderateRiskCount: moderateRiskTests.length,
      criticalFindings: highRiskTests.map(test => test.testType),
      overallRecommendations: testResults.flatMap(test => test.recommendations).slice(0, 3)
    };
  };

  const getContactMethodIcon = () => {
    switch (contactMethod) {
      case 'telegram': return <Send className="w-4 h-4" />;
      case 'email': return <Mail className="w-4 h-4" />;
    }
  };

  const getContactPlaceholder = () => {
    switch (contactMethod) {
      case 'telegram': return '@doctor_username или номер телефона';
      case 'email': return 'doctor@clinic.com';
    }
  };

  if (sent) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="bg-medical-gradient">
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="text-lg font-medium mb-2">Результаты отправлены!</h3>
            <p className="text-gray-600">
              Результаты тестирования {patientName} успешно отправлены врачу
            </p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-medical-gradient">
        <DialogHeader>
          <DialogTitle className="text-primary-medical">
            Отправить результаты врачу
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Сводка результатов */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Сводка результатов для {patientName}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="text-center">
                  <div className="text-2xl font-semibold text-primary-medical">{testResults.length}</div>
                  <div className="text-sm text-gray-600">Всего тестов</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-semibold text-red-600">
                    {testResults.filter(t => t.severity === 'severe').length}
                  </div>
                  <div className="text-sm text-gray-600">Критических</div>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-2">
                {testResults.map((test, index) => (
                  <Badge 
                    key={index}
                    variant={test.severity === 'severe' ? 'destructive' : 
                           test.severity === 'moderate' ? 'default' : 'secondary'}
                  >
                    {test.testType}: {test.score}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Настройки отправки */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="contactMethod">Способ связи</Label>
              <Select value={contactMethod} onValueChange={(value: any) => setContactMethod(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="telegram">
                    <div className="flex items-center gap-2">
                      <Send className="w-4 h-4" />
                      Telegram
                    </div>
                  </SelectItem>
                  <SelectItem value="email">
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4" />
                      Email
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="doctorContact">Контакт врача</Label>
              <div className="relative">
                <div className="absolute left-3 top-1/2 transform -translate-y-1/2">
                  {getContactMethodIcon()}
                </div>
                <Input
                  id="doctorContact"
                  value={doctorContact}
                  onChange={(e) => setDoctorContact(e.target.value)}
                  placeholder={getContactPlaceholder()}
                  className="pl-10"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="message">Дополнительное сообщение (необязательно)</Label>
              <Textarea
                id="message"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Добавьте комментарии или важные замечания для врача..."
                rows={3}
              />
            </div>
          </div>

          {error && (
            <div className="flex items-center gap-2 text-red-600 text-sm">
              <AlertCircle className="w-4 h-4" />
              {error}
            </div>
          )}

          <div className="flex gap-3">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Отмена
            </Button>
            <Button 
              onClick={handleSend} 
              disabled={loading}
              className="flex-1 bg-primary-medical hover:bg-primary-medical/90"
            >
              {loading ? 'Отправка...' : 'Отправить врачу'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}