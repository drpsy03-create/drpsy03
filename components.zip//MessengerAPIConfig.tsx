import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { MessageCircle, Send, Mail, Key, Check, AlertCircle, Info } from 'lucide-react';

export function MessengerAPIConfig() {
  const [configs, setConfigs] = useState({
    telegram: { botToken: '', chatId: '', verified: false },
    email: { smtpHost: '', smtpPort: '', username: '', password: '', verified: false }
  });

  const [testStatus, setTestStatus] = useState<{ [key: string]: 'idle' | 'testing' | 'success' | 'error' }>({
    telegram: 'idle',
    email: 'idle'
  });

  // Проверка сохраненных конфигураций при загрузке
  useEffect(() => {
    const savedConfigs = localStorage.getItem('messengerConfigs');
    if (savedConfigs) {
      setConfigs(JSON.parse(savedConfigs));
    }
  }, []);

  const saveConfig = (type: 'telegram' | 'email', config: any) => {
    const newConfigs = { ...configs, [type]: config };
    setConfigs(newConfigs);
    localStorage.setItem('messengerConfigs', JSON.stringify(newConfigs));
  };

  const testConnection = async (type: 'telegram' | 'email') => {
    setTestStatus(prev => ({ ...prev, [type]: 'testing' }));
    
    try {
      if (type === 'telegram') {
        const botToken = configs.telegram.botToken;
        const chatId = configs.telegram.chatId;
        
        if (!botToken || !chatId) {
          throw new Error('Bot Token и Chat ID обязательны');
        }

        // Тестируем отправку сообщения
        const response = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            chat_id: chatId,
            text: '🧪 Тест подключения из системы психиатрического мониторинга. Интеграция работает успешно!'
          })
        });

        const result = await response.json();
        
        if (!result.ok) {
          throw new Error(result.description || 'Ошибка Telegram API');
        }
        
        setTestStatus(prev => ({ ...prev, [type]: 'success' }));
        const newConfig = { ...configs[type], verified: true };
        saveConfig(type, newConfig);
      } else if (type === 'email') {
        // Здесь будет тестирование email
        await new Promise(resolve => setTimeout(resolve, 1000));
        setTestStatus(prev => ({ ...prev, [type]: 'success' }));
        const newConfig = { ...configs[type], verified: true };
        saveConfig(type, newConfig);
      }
    } catch (error) {
      console.error(`Test connection error for ${type}:`, error);
      setTestStatus(prev => ({ ...prev, [type]: 'error' }));
      alert(`Ошибка тестирования ${type}: ${error.message}`);
    }
  };

  const getStatusBadge = (type: string) => {
    if (configs[type as keyof typeof configs]?.verified) {
      return <Badge className="bg-green-100 text-green-800"><Check className="w-3 h-3 mr-1" />Подключено</Badge>;
    }
    return <Badge variant="outline" className="text-gray-600">Не настроено</Badge>;
  };

  const getTestButton = (type: 'telegram' | 'email') => {
    const status = testStatus[type];
    const isDisabled = status === 'testing';
    
    return (
      <Button 
        variant="outline" 
        size="sm" 
        onClick={() => testConnection(type)}
        disabled={isDisabled}
        className="mt-4"
      >
        {status === 'testing' && <div className="w-4 h-4 mr-2 border-2 border-gray-300 border-t-blue-600 rounded-full animate-spin" />}
        {status === 'success' && <Check className="w-4 h-4 mr-2 text-green-600" />}
        {status === 'error' && <AlertCircle className="w-4 h-4 mr-2 text-red-600" />}
        {status === 'testing' ? 'Проверка...' : 'Проверить подключение'}
      </Button>
    );
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Key className="h-5 w-5" />
          Настройка отправки результатов
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="telegram" className="space-y-4">
          <TabsList>
            <TabsTrigger value="telegram" className="flex items-center gap-2">
              <Send className="w-4 h-4" />
              Telegram
              {getStatusBadge('telegram')}
            </TabsTrigger>
            <TabsTrigger value="email" className="flex items-center gap-2">
              <Mail className="w-4 h-4" />
              Email
              {getStatusBadge('email')}
            </TabsTrigger>
          </TabsList>

<TabsContent value="telegram" className="space-y-4">
            <div className="space-y-4">
              <div>
                <Label htmlFor="telegram-bot-token">Bot Token</Label>
                <Input
                  id="telegram-bot-token"
                  type="password"
                  value={configs.telegram.botToken}
                  onChange={(e) => saveConfig('telegram', { ...configs.telegram, botToken: e.target.value })}
                  placeholder="Введите token от @BotFather"
                />
              </div>
              <div>
                <Label htmlFor="telegram-chat-id">Chat ID врача</Label>
                <Input
                  id="telegram-chat-id"
                  value={configs.telegram.chatId}
                  onChange={(e) => saveConfig('telegram', { ...configs.telegram, chatId: e.target.value })}
                  placeholder="ID чата или канала для отправки"
                />
              </div>
              <div className="flex items-start gap-2 p-3 bg-blue-50 rounded-lg">
                <Info className="w-4 h-4 text-blue-600 mt-0.5" />
                <div className="text-sm text-blue-800">
                  <p className="font-medium">Настройка Telegram бота:</p>
                  <p>1. Напишите @BotFather в Telegram</p>
                  <p>2. Создайте бота командой /newbot</p>
                  <p>3. Получите токен</p>
                  <p>4. Добавьте бота в чат с врачом</p>
                  <p>5. Получите Chat ID (напишите @userinfobot)</p>
                </div>
              </div>
              {getTestButton('telegram')}
            </div>
          </TabsContent>

          <TabsContent value="email" className="space-y-4">
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="smtp-host">SMTP Host</Label>
                  <Input
                    id="smtp-host"
                    value={configs.email.smtpHost}
                    onChange={(e) => saveConfig('email', { ...configs.email, smtpHost: e.target.value })}
                    placeholder="smtp.gmail.com"
                  />
                </div>
                <div>
                  <Label htmlFor="smtp-port">Port</Label>
                  <Input
                    id="smtp-port"
                    value={configs.email.smtpPort}
                    onChange={(e) => saveConfig('email', { ...configs.email, smtpPort: e.target.value })}
                    placeholder="587"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="email-username">Email</Label>
                <Input
                  id="email-username"
                  type="email"
                  value={configs.email.username}
                  onChange={(e) => saveConfig('email', { ...configs.email, username: e.target.value })}
                  placeholder="your-email@gmail.com"
                />
              </div>
              <div>
                <Label htmlFor="email-password">Пароль приложения</Label>
                <Input
                  id="email-password"
                  type="password"
                  value={configs.email.password}
                  onChange={(e) => saveConfig('email', { ...configs.email, password: e.target.value })}
                  placeholder="Пароль приложения (не основной пароль)"
                />
              </div>
              <div className="flex items-start gap-2 p-3 bg-blue-50 rounded-lg">
                <Info className="w-4 h-4 text-blue-600 mt-0.5" />
                <div className="text-sm text-blue-800">
                  <p className="font-medium">Настройка Email:</p>
                  <p>Используйте пароль приложения, а не основной пароль аккаунта</p>
                  <p>Для Gmail: Настройки → Безопасность → Пароли приложений</p>
                </div>
              </div>
              {getTestButton('email')}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}